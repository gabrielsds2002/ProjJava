package co2;

public class conta {
	
	    double saldo;
	

}
