package co2;

public class Pessoa {
	   private String nome;
	    private String sexo;
	    private String CPF;
	    private String tel;
	    private String cidade;

	    public Pessoa() {
	    }

	    public String getNome() {
	        return this.nome;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }

	    public String getSexo() {
	        return this.sexo;
	    }

	    public void setSexo(String sexo) {
	        this.sexo = sexo;
	    }

	    public String getCPF() {
	        return this.CPF;
	    }

	    public void setCPF(String cPF) {
	        this.CPF = cPF;
	    }

	    public String getTel() {
	        return this.tel;
	    }

	    public void setTel(String tel) {
	        this.tel = tel;
	    }

	    public String getCidade() {
	        return this.cidade;
	    }

	    public void setCidade(String cidade) {
	        this.cidade = cidade;
	    }

}
