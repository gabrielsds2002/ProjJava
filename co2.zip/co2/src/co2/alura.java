package co2;

public class alura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * double salario = 3300.0;
		 * 
		 * if(salario < 2600.0) System.out.println("A sua aliquota � de 15%");
		 * System.out.println("Voc� pode deduzir at� R$ 350");
		 * 
		 * if(salario < 3750.0) System.out.println("A sua aliquota � de 22,5%");
		 * System.out.println("Voc� pode deduzir at� R$ 636");
		 */

	;
	}

}
